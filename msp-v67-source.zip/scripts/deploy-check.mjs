#!/usr/bin/env node
/**
 * Assistant de publication — Master Soutien Pédagogique
 * ---------------------------------------------
 * Une seule commande :  npm run deploy:check
 *   1. Construit automatiquement l'application si nécessaire (npm run build:lowmem).
 *   2. Vérifie les fichiers présents dans dist/ ET deploy/, et que index.html
 *      charge bien le bundle construit (`./assets/main-…`), jamais `/src/main.tsx`.
 *   3. Affiche la marche à suivre (2 minutes) pour Netlify et Vercel.
 *
 * Aucune bibliothèque requise (Node.js ≥ 18).
 */
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { execSync } from 'node:child_process';

const DIST = join(process.cwd(), 'dist');
const DEPLOY = join(process.cwd(), 'deploy');
const ok = (b) => (b ? '✅' : '❌');
const hr = '─'.repeat(62);

console.log('\n' + '═'.repeat(62));
console.log('  ASSISTANT DE PUBLICATION — MASTER SOUTIEN PÉDAGOGIQUE');
console.log('═'.repeat(62));

/* 1 — construction ------------------------------------------------ */
if (!existsSync(join(DIST, 'index.html')) || !existsSync(join(DEPLOY, 'index.html'))) {
  console.log('\n[1/3] dist/ ou deploy/ introuvable → construction automatique…');
  try {
    execSync('npm run build:lowmem', { stdio: 'inherit' });
  } catch {
    console.error('❌ Le build a échoué. Vérifiez que les dépendances sont installées : npm install');
    process.exit(1);
  }
} else {
  console.log('\n[1/3] Application déjà construite (relancez « npm run build:lowmem » pour une mise à jour).');
}

/* 2 — vérifications ---------------------------------------------- */
console.log('\n[2/3] Vérification des fichiers de publication :');
const required = ['index.html', '404.html', 'sw.js', 'vercel.json', '_redirects', 'manifest.json'];
let allOk = true;
for (const [label, dir] of [['dist', DIST], ['deploy', DEPLOY]]) {
  for (const f of required) {
    const present = existsSync(join(dir, f));
    if (!present) allOk = false;
    console.log(`  ${ok(present)} ${label}/${f}${present ? '' : '  ← manquant !'}`);
  }

  const indexPath = join(dir, 'index.html');
  const indexHtml = existsSync(indexPath) ? readFileSync(indexPath, 'utf8') : '';
  const builtScript = /src="\.\/assets\/main-[^"]+\.js"/.test(indexHtml);
  const sourceScript = indexHtml.includes('src="/src/main.tsx"');
  if (!builtScript || sourceScript) allOk = false;
  console.log(`  ${ok(builtScript && !sourceScript)} ${label}/index.html charge le bundle construit (pas /src/main.tsx)`);
}
if (!allOk) {
  console.error('❌ Publication non prête → exécutez : npm run build:lowmem, puis relancez cette commande.');
  process.exit(1);
}
const size = Math.round(statSync(join(DEPLOY, 'index.html')).size / 1024);
console.log(`  (deploy/index.html : ${size} Ko + ses fichiers assets/ — déposez le CONTENU de deploy/)`);

/* 3 — marche à suivre -------------------------------------------- */
console.log('\n[3/3] Publication en 2 minutes :\n');
console.log(hr);
console.log('  OPTION A — NETLIFY (gratuit, sans compte Git)');
console.log(hr);
console.log('  1. Ouvrez https://app.netlify.com/drop');
console.log('  2. Ouvrez deploy/, sélectionnez TOUT son contenu, puis glissez-le dans la zone de dépôt.');
console.log('     (Glisser le dossier deploy/ lui-même fonctionne aussi : son index.html est à la racine.)');
console.log('  3. C’est en ligne ! (adresse en fin de page → « Site configuration » pour la renommer).');
console.log('  ⚠️  Ne déposez PAS le .zip ni le dossier source du projet.');
console.log(hr);
console.log('  OPTION B — VERCEL (gratuit, sans compte Git)');
console.log(hr);
console.log('  1. Ouvrez https://vercel.com/new → onglet « Deploy » (ou vercel.com/drag-drop).');
console.log('  2. Glissez le dossier deploy/ (son index.html est à la racine).');
console.log('  3. Vercel détecte automatiquement deploy/vercel.json : toutes les pages répondent.');
console.log('     Si l’écran vous demande un « Project Name », laissez le pré-rempli → Deploy.');
console.log('  ⚠️  Si vous voyez « 404: NOT_FOUND » : vous avez déposé le .zip ou la source.');
console.log('      Reprenez à l’étape 2 avec deploy/.\n');
console.log(hr);
console.log('  OPTION C — VERCEL avec compte GitHub (mises à jour automatiques)');
console.log(hr);
console.log('  1. Poussez le dossier du projet (sans node_modules ni dist) sur GitHub.');
console.log('  2. vercel.com/new → Importez le dépôt → Framework « Vite » →');
console.log('     Output Directory : dist → Deploy (le vercel.json fait le reste).');
console.log('  3. À chaque git push, Vercel reconstruit et publie.\n');
console.log('POUR METTRE À JOUR une version déjà en ligne : npm run build:lowmem, puis re-déposez deploy/ au même endroit.');
console.log('═'.repeat(62) + '\n');
